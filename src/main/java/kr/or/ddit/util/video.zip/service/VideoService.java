package kr.or.ddit.util.video.service;


public interface VideoService {
	// 채팅방 생성 및 URL 제공
	public int createVideoChatRoom(int counselId);
}
